<?php echo e($slot); ?>

<?php /**PATH /home/malcalaboratorie/public_html/platform/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>