<?php echo e($slot); ?>

<?php /**PATH /home/malcalaboratorie/public_html/platform/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>