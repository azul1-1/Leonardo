<p>Click the following link to reset your password:</p>

<a href="<?php echo e($url); ?>">Reset Password</a><?php /**PATH /home/malcalaboratorie/public_html/platform/resources/views/mails/reset2.blade.php ENDPATH**/ ?>