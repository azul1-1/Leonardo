[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/malcalaboratorie/public_html/platform/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>