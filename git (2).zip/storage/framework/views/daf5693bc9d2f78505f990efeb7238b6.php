<html>
    
    <h1>hola <?php echo e($name); ?></h1>
</html>

<?php /**PATH /home/malcalaboratorie/public_html/platform/resources/views/email.blade.php ENDPATH**/ ?>