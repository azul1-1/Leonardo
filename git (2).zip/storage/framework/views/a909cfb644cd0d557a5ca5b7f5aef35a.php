<?php echo e($slot); ?>

<?php /**PATH /home/malcalaboratorie/public_html/platform/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>