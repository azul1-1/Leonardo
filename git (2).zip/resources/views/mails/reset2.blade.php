<p>Click the following link to reset your password:</p>

<a href="{{$url}}">Reset Password</a>